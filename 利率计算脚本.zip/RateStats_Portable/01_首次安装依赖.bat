@echo off
setlocal
cd /d "%~dp0"

set "PY_CMD=python"
where python >nul 2>nul
if errorlevel 1 (
  where py >nul 2>nul
  if errorlevel 1 (
    echo Python not found in PATH.
    echo Please install Python 3.10+ and add it to PATH.
    pause
    exit /b 1
  )
  set "PY_CMD=py -3"
)

echo [1/2] Upgrade pip...
%PY_CMD% -m pip install --upgrade pip
if errorlevel 1 goto :err

echo [2/2] Install dependencies...
%PY_CMD% -m pip install -r requirements.txt
if errorlevel 1 goto :err

echo.
echo Dependencies installed successfully.
pause
exit /b 0

:err
echo.
echo Install failed.
pause
exit /b 1
