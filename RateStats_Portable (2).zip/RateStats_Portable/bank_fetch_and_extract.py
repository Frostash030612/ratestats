from __future__ import annotations

"""
Citibank 抓取与汇总模块（fetch_and_extract）。

这份模块把主脚本里的“抓取总入口”函数单独拆出来，降低主脚本主干的体积。

注意：
- 各银行解析函数已迁移到 `bank_extractors.impl` 包，本模块在模块级 `import` 后直接使用，
  不再依赖 `import __main__`。
"""

from typing import Any, Dict, List, Optional

from bank_safety import safe_call
from datetime import datetime, timezone

import requests
from bs4 import BeautifulSoup

from url_sources import (
    DEFAULT_CIMB_FCY_URL,
    DEFAULT_CIMB_SGD_URL,
    DEFAULT_HL_FD_URL,
    DEFAULT_HLF_FD_URL,
    DEFAULT_HSBC_TD_URL,
    DEFAULT_ICBC_FD_URL,
    DEFAULT_OCBC_FD_URL,
    DEFAULT_RHB_FD_URL,
    DEFAULT_RHB_FCY_FD_URL,
    DEFAULT_SCB_SGD_TD_URL,
    DEFAULT_SCB_FCY_FD_URL,
    DEFAULT_SIF_FD_URL,
    DEFAULT_SBI_SGD_PROMO_URL,
    DEFAULT_SBI_USD_PROMO_URL,
    DEFAULT_UOB_SGD_TD_URL,
    DEFAULT_BOC_PROMO_URL,
    DEFAULT_CITI_SGD_BOARD_URL,
    DEFAULT_DBS_SGD_BOARD_URL,
    DEFAULT_HL_SGD_BOARD_URL,
    DEFAULT_HLF_SGD_BOARD_URL,
    DEFAULT_HSBC_SGD_BOARD_URL,
    DEFAULT_ICBC_SGD_BOARD_URL,
    DEFAULT_MAYBANK_SGD_BOARD_URL,
    DEFAULT_OCBC_SGD_BOARD_URL,
    DEFAULT_RHB_SGD_BOARD_PDF_URL,
    DEFAULT_SIF_SGD_BOARD_URL,
    DEFAULT_SCB_SGD_BOARD_URL,
    DEFAULT_SBI_SGD_BOARD_URL,
    DEFAULT_UOB_SGD_BOARD_URL,
    DEFAULT_HL_FCY_BOARD_URL,
    DEFAULT_HSBC_FCY_BOARD_URL,
    DEFAULT_MAYBANK_FCY_BOARD_URL,
    DEFAULT_SCB_FCY_BOARD_URL,
    DEFAULT_SBI_FCY_BOARD_URL,
    DEFAULT_RHB_FCY_BOARD_PDF_URL,
    DEFAULT_BEA_SGD_BOARD_API_URL,
    DEFAULT_BEA_FCY_BOARD_API_URL,
    DEFAULT_BOC_BOARD_URL,
)

from bank_extractors import impl as _x


def _get_with_hsbc_rates_fallback(sess, url: str, timeout: float):
    """
    HSBC rates 页面偶发/区域化路由问题：
    - `.../zh-sg/rates/...` 可能返回 404
    - 对该情况自动回退重试 `.../rates/...`
    """
    r = sess.get(url, timeout=timeout)
    if r.status_code == 404 and "/zh-sg/rates/" in (url or "").lower():
        fallback = url.replace("/zh-sg/rates/", "/rates/")
        r2 = sess.get(fallback, timeout=timeout)
        if r2.status_code < 400:
            return r2
    return r


@safe_call(
    context="抓取与汇总（fetch_and_extract）",
    default_factory=lambda e, a, k: {},
)
def fetch_and_extract(
    url: str,
    timeout: float,
    use_env_proxy: bool,
    cimb_fcy_url: Optional[str] = DEFAULT_CIMB_FCY_URL,
    cimb_sgd_url: Optional[str] = DEFAULT_CIMB_SGD_URL,
    hl_fd_url: Optional[str] = DEFAULT_HL_FD_URL,
    hlf_promo_url: Optional[str] = DEFAULT_HLF_FD_URL,
    hsbc_td_url: Optional[str] = DEFAULT_HSBC_TD_URL,
    icbc_fd_url: Optional[str] = DEFAULT_ICBC_FD_URL,
    ocbc_fd_url: Optional[str] = DEFAULT_OCBC_FD_URL,
    rhb_fd_url: Optional[str] = DEFAULT_RHB_FD_URL,
    rhb_fcy_fd_url: Optional[str] = DEFAULT_RHB_FCY_FD_URL,
    sif_fd_url: Optional[str] = DEFAULT_SIF_FD_URL,
    scb_sgd_fd_url: Optional[str] = DEFAULT_SCB_SGD_TD_URL,
    scb_fcy_fd_url: Optional[str] = DEFAULT_SCB_FCY_FD_URL,
    sbi_sgd_fd_url: Optional[str] = DEFAULT_SBI_SGD_PROMO_URL,
    sbi_fcy_fd_url: Optional[str] = DEFAULT_SBI_USD_PROMO_URL,
    uob_sgd_fd_url: Optional[str] = DEFAULT_UOB_SGD_TD_URL,
    boc_promo_url: Optional[str] = DEFAULT_BOC_PROMO_URL,
    include_sgd_board: bool = True,
    citi_sgd_board_url: Optional[str] = DEFAULT_CITI_SGD_BOARD_URL,
    dbs_sgd_board_url: Optional[str] = DEFAULT_DBS_SGD_BOARD_URL,
    hl_sgd_board_url: Optional[str] = DEFAULT_HL_SGD_BOARD_URL,
    hlf_sgd_board_url: Optional[str] = DEFAULT_HLF_SGD_BOARD_URL,
    hsbc_sgd_board_url: Optional[str] = DEFAULT_HSBC_SGD_BOARD_URL,
    icbc_sgd_board_url: Optional[str] = DEFAULT_ICBC_SGD_BOARD_URL,
    maybank_sgd_board_url: Optional[str] = DEFAULT_MAYBANK_SGD_BOARD_URL,
    ocbc_sgd_board_url: Optional[str] = DEFAULT_OCBC_SGD_BOARD_URL,
    rhb_sgd_board_pdf_url: Optional[str] = DEFAULT_RHB_SGD_BOARD_PDF_URL,
    sif_sgd_board_url: Optional[str] = DEFAULT_SIF_SGD_BOARD_URL,
    scb_sgd_board_url: Optional[str] = DEFAULT_SCB_SGD_BOARD_URL,
    sbi_sgd_board_url: Optional[str] = DEFAULT_SBI_SGD_BOARD_URL,
    uob_sgd_board_url: Optional[str] = DEFAULT_UOB_SGD_BOARD_URL,
    hl_fcy_board_url: Optional[str] = DEFAULT_HL_FCY_BOARD_URL,
    hsbc_fcy_board_url: Optional[str] = DEFAULT_HSBC_FCY_BOARD_URL,
    maybank_fcy_board_url: Optional[str] = DEFAULT_MAYBANK_FCY_BOARD_URL,
    scb_fcy_board_url: Optional[str] = DEFAULT_SCB_FCY_BOARD_URL,
    sbi_fcy_board_url: Optional[str] = DEFAULT_SBI_FCY_BOARD_URL,
    rhb_fcy_board_pdf_url: Optional[str] = DEFAULT_RHB_FCY_BOARD_PDF_URL,
    bea_sgd_board_api_url: Optional[str] = DEFAULT_BEA_SGD_BOARD_API_URL,
    bea_fcy_board_api_url: Optional[str] = DEFAULT_BEA_FCY_BOARD_API_URL,
    boc_board_url: Optional[str] = DEFAULT_BOC_BOARD_URL,
) -> Dict[str, Any]:
    """
    抓取 Citi 主页面 + 可选各家银行促销页/挂牌页，并汇总为统一 payload。

    payload 结构的目的：
    - 供后续 `write_rates_excel(data, ...)` 写入多 sheet Excel
    - 或供 `main()` 输出 JSON

    关键行为（与原主脚本保持一致）：
    1) 必抓 `url`（Citi all-promo）并抽取：
       - `sgd_time_deposit`
       - `fx_time_deposit_1m`
       - `other`（脚注/杂项利率，使用正则 best-effort）
    2) 若 URL 参数开启，则按银行逐一抓取其页面，并把解析结果合并到：
       - `sgd_merged`：新元相关利率合并结果
       - `fx_merged`：外币相关利率合并结果
    3) 若 `include_sgd_board=True`，则继续抓取/解析各家“挂牌板块”并写入：
       - `sgd_board_merged` + 各银行 `*_sgd_board` 元信息
       - `fx_board_merged` + 各银行 `*_fcy_board` 元信息
    """
    # 解析函数来自 bank_extractors.impl（与主脚本解耦）
    _session = _x._session
    extract_sgd_time_deposit = _x.extract_sgd_time_deposit
    extract_fx_time_deposit = _x.extract_fx_time_deposit

    extract_cimb_fcy_promo = _x.extract_cimb_fcy_promo
    merge_fx_citi_cimb = _x.merge_fx_citi_cimb
    extract_cimb_sgd_rates = _x.extract_cimb_sgd_rates
    build_sgd_merged = _x.build_sgd_merged

    extract_hl_sgd_promo = _x.extract_hl_sgd_promo
    extract_hl_fcy_promo = _x.extract_hl_fcy_promo
    append_hl_sgd_rows = _x.append_hl_sgd_rows
    append_hl_fcy_rows = _x.append_hl_fcy_rows

    extract_hlf_sgd_promo = _x.extract_hlf_sgd_promo
    append_hlf_sgd_rows = _x.append_hlf_sgd_rows

    extract_hsbc_sgd_promo = _x.extract_hsbc_sgd_promo
    append_hsbc_sgd_rows = _x.append_hsbc_sgd_rows

    extract_icbc_fd_promo = _x.extract_icbc_fd_promo
    append_icbc_sgd_rows = _x.append_icbc_sgd_rows
    append_icbc_fx_rows = _x.append_icbc_fx_rows

    extract_ocbc_sgd_promo = _x.extract_ocbc_sgd_promo
    append_ocbc_sgd_rows = _x.append_ocbc_sgd_rows

    extract_rhb_fd_promo = _x.extract_rhb_fd_promo
    append_rhb_sgd_rows = _x.append_rhb_sgd_rows
    extract_rhb_fcy_promo = _x.extract_rhb_fcy_promo
    append_rhb_fcy_rows = _x.append_rhb_fcy_rows

    extract_sif_fd_promo = _x.extract_sif_fd_promo
    append_sif_sgd_rows = _x.append_sif_sgd_rows

    extract_uob_sgd_promo = _x.extract_uob_sgd_promo
    extract_uob_fcy_promo = _x.extract_uob_fcy_promo
    append_uob_sgd_rows = _x.append_uob_sgd_rows
    append_uob_fcy_rows = _x.append_uob_fcy_rows

    extract_scb_sgd_fd_promo = _x.extract_scb_sgd_fd_promo
    append_scb_sgd_rows = _x.append_scb_sgd_rows
    extract_scb_fcy_fd_promo = _x.extract_scb_fcy_fd_promo
    append_scb_fcy_rows = _x.append_scb_fcy_rows

    extract_sbi_sgd_promo = _x.extract_sbi_sgd_promo
    append_sbi_sgd_rows = _x.append_sbi_sgd_rows
    extract_sbi_fcy_promo = _x.extract_sbi_fcy_promo
    append_sbi_fcy_rows = _x.append_sbi_fcy_rows

    extract_boc_promo = _x.extract_boc_promo
    append_boc_sgd_rows = _x.append_boc_sgd_rows
    append_boc_fx_rows = _x.append_boc_fx_rows

    extract_cimb_sgd_board = _x.extract_cimb_sgd_board
    extract_citi_sgd_board = _x.extract_citi_sgd_board
    extract_dbs_sgd_board = _x.extract_dbs_sgd_board
    extract_hl_sgd_board = _x.extract_hl_sgd_board
    extract_hlf_sgd_board = _x.extract_hlf_sgd_board
    extract_hsbc_sgd_board = _x.extract_hsbc_sgd_board
    extract_icbc_sgd_board = _x.extract_icbc_sgd_board
    extract_maybank_sgd_board = _x.extract_maybank_sgd_board
    extract_ocbc_sgd_board = _x.extract_ocbc_sgd_board
    extract_rhb_sgd_board_pdf = _x.extract_rhb_sgd_board_pdf
    extract_sif_sgd_board = _x.extract_sif_sgd_board
    extract_scb_sgd_board = _x.extract_scb_sgd_board
    extract_sbi_sgd_board = _x.extract_sbi_sgd_board
    extract_uob_sgd_board = _x.extract_uob_sgd_board

    extract_hl_fcy_board = _x.extract_hl_fcy_board
    extract_hsbc_fcy_board = _x.extract_hsbc_fcy_board
    extract_maybank_fcy_board = _x.extract_maybank_fcy_board
    extract_scb_fcy_board = _x.extract_scb_fcy_board
    extract_sbi_fcy_board = _x.extract_sbi_fcy_board
    extract_rhb_fcy_board_pdf = _x.extract_rhb_fcy_board_pdf

    extract_bea_sgd_board_from_json = _x.extract_bea_sgd_board_from_json
    extract_bea_fcy_board_from_json = _x.extract_bea_fcy_board_from_json
    extract_boc_sgd_fcy_board = _x.extract_boc_sgd_fcy_board

    # 1) 先抓 Citi all-promo 主页面并抽取最基础的核心 payload。
    sess = _session(use_env_proxy)
    r = sess.get(url, timeout=timeout)
    r.raise_for_status()
    html = r.text
    soup = BeautifulSoup(html, "lxml")
    payload: Dict[str, Any] = {
        "source_url": r.url,
        "fetched_at_utc": datetime.now(timezone.utc).isoformat(),
        "sgd_time_deposit": extract_sgd_time_deposit(soup),
        "fx_time_deposit_1m": extract_fx_time_deposit(soup),
        # 业务侧已弃用“其他利率”抓取，保持空对象以兼容下游 DataFrame 构建逻辑。
        "other": {},
    }

    # 2) CIMB FCY promo + merge 到 fx_merged
    cimb_block: Dict[str, Any] = {}
    if cimb_fcy_url:
        try:
            r2 = sess.get(cimb_fcy_url, timeout=timeout)
            r2.raise_for_status()
            soup2 = BeautifulSoup(r2.text, "lxml")
            cimb_block = extract_cimb_fcy_promo(soup2)
            cimb_block["source_url"] = r2.url
        except requests.RequestException as e:
            cimb_block = {
                "error": str(e),
                "currencies": {},
                "notes": [],
                "source_url": cimb_fcy_url,
            }
    payload["cimb_fcy_promo"] = cimb_block
    payload["fx_merged"] = merge_fx_citi_cimb(
        payload["fx_time_deposit_1m"],
        cimb_block if cimb_block and not cimb_block.get("error") else None,
    )

    # 3) CIMB SGD rates -> build sgd_merged
    cimb_sgd_soup: Optional[BeautifulSoup] = None
    cimb_sgd_block: Dict[str, Any] = {}
    if cimb_sgd_url:
        try:
            r3 = sess.get(cimb_sgd_url, timeout=timeout)
            r3.raise_for_status()
            cimb_sgd_soup = BeautifulSoup(r3.text, "lxml")
            cimb_sgd_block = extract_cimb_sgd_rates(cimb_sgd_soup)
            cimb_sgd_block["source_url"] = r3.url
        except requests.RequestException as e:
            cimb_sgd_block = {"error": str(e), "source_url": cimb_sgd_url}
    payload["cimb_sgd_rates"] = cimb_sgd_block
    payload["sgd_merged"] = build_sgd_merged(
        payload["sgd_time_deposit"],
        cimb_sgd_block if cimb_sgd_block and not cimb_sgd_block.get("error") else None,
    )

    # 4) HL：SGD+FCY promo 同页（把 rows append 进 merged）
    hl_block: Dict[str, Any] = {}
    if hl_fd_url:
        try:
            r4 = sess.get(hl_fd_url, timeout=timeout)
            r4.raise_for_status()
            soup4 = BeautifulSoup(r4.text, "lxml")
            hl_block = extract_hl_sgd_promo(soup4)
            hl_block.update(extract_hl_fcy_promo(soup4))
            hl_block["source_url"] = r4.url
        except requests.RequestException as e:
            hl_block = {"error": str(e), "source_url": hl_fd_url}
    payload["hl_fd_promo"] = hl_block
    if hl_block and not hl_block.get("error"):
        payload["sgd_merged"] = append_hl_sgd_rows(payload["sgd_merged"], hl_block)
        payload["fx_merged"] = append_hl_fcy_rows(payload["fx_merged"], hl_block)

    # 5) HLF：只做 SGD merge
    hlf_block: Dict[str, Any] = {}
    if hlf_promo_url:
        try:
            r5 = sess.get(hlf_promo_url, timeout=timeout)
            r5.raise_for_status()
            soup5 = BeautifulSoup(r5.text, "lxml")
            hlf_block = extract_hlf_sgd_promo(soup5)
            hlf_block["source_url"] = r5.url
        except requests.RequestException as e:
            hlf_block = {"error": str(e), "source_url": hlf_promo_url}
    payload["hlf_promo"] = hlf_block
    if hlf_block and not hlf_block.get("error"):
        payload["sgd_merged"] = append_hlf_sgd_rows(payload["sgd_merged"], hlf_block)

    # 6) HSBC：SGD merge
    hsbc_block: Dict[str, Any] = {}
    if hsbc_td_url:
        try:
            hs_headers = {
                **dict(sess.headers),
                "Accept-Language": "zh-SG,zh-CN;q=0.9,en-SG;q=0.8,en;q=0.7",
            }
            r6 = sess.get(hsbc_td_url, timeout=timeout, headers=hs_headers)
            r6.raise_for_status()
            soup6 = BeautifulSoup(r6.text, "lxml")
            hsbc_block = extract_hsbc_sgd_promo(soup6)
            hsbc_block["source_url"] = r6.url
        except requests.RequestException as e:
            hsbc_block = {"error": str(e), "source_url": hsbc_td_url}
    payload["hsbc_td_promo"] = hsbc_block
    if hsbc_block and not hsbc_block.get("error"):
        payload["sgd_merged"] = append_hsbc_sgd_rows(payload["sgd_merged"], hsbc_block)

    # 7) ICBC：SGD + FCY
    icbc_block: Dict[str, Any] = {}
    if icbc_fd_url:
        try:
            r7 = sess.get(icbc_fd_url, timeout=timeout)
            r7.raise_for_status()
            soup7 = BeautifulSoup(r7.text, "lxml")
            icbc_block = extract_icbc_fd_promo(soup7)
            icbc_block["source_url"] = r7.url
        except requests.RequestException as e:
            icbc_block = {"error": str(e), "source_url": icbc_fd_url}
    payload["icbc_fd_promo"] = icbc_block
    if icbc_block and not icbc_block.get("error"):
        payload["sgd_merged"] = append_icbc_sgd_rows(payload["sgd_merged"], icbc_block)
        payload["fx_merged"] = append_icbc_fx_rows(payload["fx_merged"], icbc_block)

    # 8) OCBC：SGD
    ocbc_block: Dict[str, Any] = {}
    if ocbc_fd_url:
        try:
            r8 = sess.get(ocbc_fd_url, timeout=timeout)
            r8.raise_for_status()
            soup8 = BeautifulSoup(r8.text, "lxml")
            ocbc_block = extract_ocbc_sgd_promo(soup8)
            ocbc_block["source_url"] = r8.url
        except requests.RequestException as e:
            ocbc_block = {"error": str(e), "source_url": ocbc_fd_url}
    payload["ocbc_fd_promo"] = ocbc_block
    if ocbc_block and not ocbc_block.get("error"):
        payload["sgd_merged"] = append_ocbc_sgd_rows(payload["sgd_merged"], ocbc_block)

    # 9) RHB：SGD + FCY
    rhb_block: Dict[str, Any] = {}
    if rhb_fd_url:
        try:
            r9 = sess.get(rhb_fd_url, timeout=timeout)
            r9.raise_for_status()
            soup9 = BeautifulSoup(r9.text, "lxml")
            rhb_block = extract_rhb_fd_promo(soup9)
            rhb_block["source_url"] = r9.url
        except requests.RequestException as e:
            rhb_block = {"error": str(e), "source_url": rhb_fd_url}
    payload["rhb_fd_promo"] = rhb_block
    if rhb_block and not rhb_block.get("error"):
        payload["sgd_merged"] = append_rhb_sgd_rows(payload["sgd_merged"], rhb_block)

    rhb_fcy_block: Dict[str, Any] = {}
    if rhb_fcy_fd_url:
        try:
            r9b = sess.get(rhb_fcy_fd_url, timeout=timeout)
            r9b.raise_for_status()
            soup9b = BeautifulSoup(r9b.text, "lxml")
            rhb_fcy_block = extract_rhb_fcy_promo(soup9b)
            rhb_fcy_block["source_url"] = r9b.url
        except requests.RequestException as e:
            rhb_fcy_block = {"error": str(e), "source_url": rhb_fcy_fd_url}
    payload["rhb_fcy_fd_promo"] = rhb_fcy_block
    if rhb_fcy_block and not rhb_fcy_block.get("error"):
        payload["fx_merged"] = append_rhb_fcy_rows(payload["fx_merged"], rhb_fcy_block)

    # 10) SingFinance：SGD
    sif_block: Dict[str, Any] = {}
    if sif_fd_url:
        try:
            r10 = sess.get(sif_fd_url, timeout=timeout)
            r10.raise_for_status()
            soup10 = BeautifulSoup(r10.text, "lxml")
            sif_block = extract_sif_fd_promo(soup10)
            sif_block["source_url"] = r10.url
        except requests.RequestException as e:
            sif_block = {"error": str(e), "source_url": sif_fd_url}
    payload["sif_fd_promo"] = sif_block
    if sif_block and not sif_block.get("error"):
        payload["sgd_merged"] = append_sif_sgd_rows(payload["sgd_merged"], sif_block)

    # 11) UOB：同页检测 FCY promo 并分别 merge
    uob_block_sgd: Dict[str, Any] = {}
    uob_block_fcy: Dict[str, Any] = {}
    if uob_sgd_fd_url:
        try:
            r_uob = sess.get(uob_sgd_fd_url, timeout=timeout)
            r_uob.raise_for_status()
            soup_uob = BeautifulSoup(r_uob.text, "lxml")
            uob_block_sgd = extract_uob_sgd_promo(soup_uob)
            uob_block_sgd["source_url"] = r_uob.url

            # Same page: detect FCY promo table existence (and parse if present).
            uob_block_fcy = extract_uob_fcy_promo(soup_uob)
            uob_block_fcy["source_url"] = r_uob.url
        except requests.RequestException as e:
            uob_block_sgd = {"error": str(e), "source_url": uob_sgd_fd_url}
            uob_block_fcy = {"error": str(e), "source_url": uob_sgd_fd_url}
    payload["uob_sgd_fd_promo"] = uob_block_sgd
    payload["uob_fcy_promo"] = uob_block_fcy
    if uob_block_sgd and not uob_block_sgd.get("error"):
        payload["sgd_merged"] = append_uob_sgd_rows(payload["sgd_merged"], uob_block_sgd)
    if uob_block_fcy and not uob_block_fcy.get("error"):
        if uob_block_fcy.get("has_fcy_promo_table"):
            payload["fx_merged"] = append_uob_fcy_rows(payload["fx_merged"], uob_block_fcy)

    # 12) SCB：SGD + FCY
    scb_block: Dict[str, Any] = {}
    if scb_sgd_fd_url:
        try:
            r11 = sess.get(scb_sgd_fd_url, timeout=timeout)
            r11.raise_for_status()
            soup11 = BeautifulSoup(r11.text, "lxml")
            scb_block = extract_scb_sgd_fd_promo(soup11)
            scb_block["source_url"] = r11.url
        except requests.RequestException as e:
            scb_block = {"error": str(e), "source_url": scb_sgd_fd_url}
    payload["scb_sgd_promo"] = scb_block
    if scb_block and not scb_block.get("error"):
        payload["sgd_merged"] = append_scb_sgd_rows(payload["sgd_merged"], scb_block)

    scb_fcy_block: Dict[str, Any] = {}
    if scb_fcy_fd_url:
        try:
            r12 = sess.get(scb_fcy_fd_url, timeout=timeout)
            r12.raise_for_status()
            soup12 = BeautifulSoup(r12.text, "lxml")
            scb_fcy_block = extract_scb_fcy_fd_promo(soup12)
            scb_fcy_block["source_url"] = r12.url
        except requests.RequestException as e:
            scb_fcy_block = {"error": str(e), "source_url": scb_fcy_fd_url}
    payload["scb_fcy_fd_promo"] = scb_fcy_block
    if scb_fcy_block and not scb_fcy_block.get("error"):
        payload["fx_merged"] = append_scb_fcy_rows(payload["fx_merged"], scb_fcy_block)

    # 13) SBI：SGD + FCY（FCY 即 USD 表/同源）
    sbi_block: Dict[str, Any] = {}
    if sbi_sgd_fd_url:
        try:
            r13 = sess.get(sbi_sgd_fd_url, timeout=timeout)
            r13.raise_for_status()
            soup13 = BeautifulSoup(r13.text, "lxml")
            sbi_block = extract_sbi_sgd_promo(soup13)
            sbi_block["source_url"] = r13.url
        except requests.RequestException as e:
            sbi_block = {"error": str(e), "source_url": sbi_sgd_fd_url}
    payload["sbi_sgd_promo"] = sbi_block
    if sbi_block and not sbi_block.get("error"):
        payload["sgd_merged"] = append_sbi_sgd_rows(payload["sgd_merged"], sbi_block)

    sbi_fcy_block: Dict[str, Any] = {}
    if sbi_fcy_fd_url:
        try:
            r14 = sess.get(sbi_fcy_fd_url, timeout=timeout)
            r14.raise_for_status()
            soup14 = BeautifulSoup(r14.text, "lxml")
            sbi_fcy_block = extract_sbi_fcy_promo(soup14)
            sbi_fcy_block["source_url"] = r14.url
        except requests.RequestException as e:
            sbi_fcy_block = {"error": str(e), "source_url": sbi_fcy_fd_url}
    payload["sbi_fcy_promo"] = sbi_fcy_block
    if sbi_fcy_block and not sbi_fcy_block.get("error"):
        payload["fx_merged"] = append_sbi_fcy_rows(payload["fx_merged"], sbi_fcy_block)

    # 14) BOC：SGD + FCY 同页面抓取与 merge
    boc_block: Dict[str, Any] = {}
    if boc_promo_url:
        try:
            rboc = sess.get(boc_promo_url, timeout=timeout)
            rboc.raise_for_status()
            rboc.encoding = rboc.apparent_encoding or rboc.encoding
            sboc = BeautifulSoup(rboc.text, "lxml")
            boc_block = extract_boc_promo(sboc)
            boc_block["source_url"] = rboc.url
        except requests.RequestException as e:
            boc_block = {"error": str(e), "source_url": boc_promo_url}
    payload["boc_promo"] = boc_block
    if boc_block and not boc_block.get("error"):
        payload["sgd_merged"] = append_boc_sgd_rows(payload["sgd_merged"], boc_block)
        payload["fx_merged"] = append_boc_fx_rows(payload["fx_merged"], boc_block)

    # ------------------------------------------------------------
    # 15) SGD/FCY board（挂牌板块）可选抓取与合并
    # ------------------------------------------------------------
    sgd_board_merged: List[Dict[str, Any]] = []
    citi_sgd_board_meta: Dict[str, Any] = {}
    dbs_sgd_board_meta: Dict[str, Any] = {}
    hl_sgd_board_meta: Dict[str, Any] = {}
    hlf_sgd_board_meta: Dict[str, Any] = {}
    hsbc_sgd_board_meta: Dict[str, Any] = {}
    icbc_sgd_board_meta: Dict[str, Any] = {}
    maybank_sgd_board_meta: Dict[str, Any] = {}
    ocbc_sgd_board_meta: Dict[str, Any] = {}
    rhb_sgd_board_meta: Dict[str, Any] = {}
    sif_sgd_board_meta: Dict[str, Any] = {}
    scb_sgd_board_meta: Dict[str, Any] = {}
    sbi_sgd_board_meta: Dict[str, Any] = {}
    uob_sgd_board_meta: Dict[str, Any] = {}

    fx_board_merged: List[Dict[str, Any]] = []
    hl_fcy_board_meta: Dict[str, Any] = {}
    hsbc_fcy_board_meta: Dict[str, Any] = {}
    maybank_fcy_board_meta: Dict[str, Any] = {}
    scb_fcy_board_meta: Dict[str, Any] = {}
    sbi_fcy_board_meta: Dict[str, Any] = {}
    rhb_fcy_board_meta: Dict[str, Any] = {}
    bea_sgd_board_meta: Dict[str, Any] = {}
    bea_fcy_board_meta: Dict[str, Any] = {}
    boc_sgd_board_meta: Dict[str, Any] = {}
    boc_fcy_board_meta: Dict[str, Any] = {}

    if include_sgd_board:
        # 15.1) Citi board / 各银行 SGD board
        if cimb_sgd_soup is not None:
            sgd_board_merged.extend(extract_cimb_sgd_board(cimb_sgd_soup))
        if citi_sgd_board_url:
            try:
                rc = sess.get(citi_sgd_board_url, timeout=timeout)
                rc.raise_for_status()
                sc = BeautifulSoup(rc.text, "lxml")
                cr = extract_citi_sgd_board(sc)
                sgd_board_merged.extend(cr)
                citi_sgd_board_meta = {"source_url": rc.url, "row_count": len(cr)}
            except requests.RequestException as e:
                citi_sgd_board_meta = {"error": str(e), "source_url": citi_sgd_board_url}

        if dbs_sgd_board_url:
            try:
                rd = sess.get(dbs_sgd_board_url, timeout=timeout)
                rd.raise_for_status()
                sd = BeautifulSoup(rd.text, "lxml")
                dr = extract_dbs_sgd_board(sd)
                sgd_board_merged.extend(dr)
                dbs_sgd_board_meta = {"source_url": rd.url, "row_count": len(dr)}
            except requests.RequestException as e:
                dbs_sgd_board_meta = {"error": str(e), "source_url": dbs_sgd_board_url}

        if hl_sgd_board_url:
            try:
                rh = sess.get(hl_sgd_board_url, timeout=timeout)
                rh.raise_for_status()
                sh = BeautifulSoup(rh.text, "lxml")
                hr = extract_hl_sgd_board(sh)
                sgd_board_merged.extend(hr)
                hl_sgd_board_meta = {"source_url": rh.url, "row_count": len(hr)}
            except requests.RequestException as e:
                hl_sgd_board_meta = {"error": str(e), "source_url": hl_sgd_board_url}

        if hlf_sgd_board_url:
            try:
                rf = sess.get(hlf_sgd_board_url, timeout=timeout)
                rf.raise_for_status()
                sf = BeautifulSoup(rf.text, "lxml")
                fr = extract_hlf_sgd_board(sf)
                sgd_board_merged.extend(fr)
                hlf_sgd_board_meta = {"source_url": rf.url, "row_count": len(fr)}
            except requests.RequestException as e:
                hlf_sgd_board_meta = {"error": str(e), "source_url": hlf_sgd_board_url}

        if hsbc_sgd_board_url:
            try:
                rh_sb = _get_with_hsbc_rates_fallback(sess, hsbc_sgd_board_url, timeout)
                rh_sb.raise_for_status()
                sh_sb = BeautifulSoup(rh_sb.text, "lxml")
                hsr = extract_hsbc_sgd_board(sh_sb)
                sgd_board_merged.extend(hsr)
                hsbc_sgd_board_meta = {"source_url": rh_sb.url, "row_count": len(hsr)}
            except requests.RequestException as e:
                hsbc_sgd_board_meta = {"error": str(e), "source_url": hsbc_sgd_board_url}

        if icbc_sgd_board_url:
            try:
                ri_bc = sess.get(icbc_sgd_board_url, timeout=timeout)
                ri_bc.raise_for_status()
                si_bc = BeautifulSoup(ri_bc.text, "lxml")
                icr = extract_icbc_sgd_board(si_bc)
                sgd_board_merged.extend(icr)
                icbc_sgd_board_meta = {"source_url": ri_bc.url, "row_count": len(icr)}
            except requests.RequestException as e:
                icbc_sgd_board_meta = {"error": str(e), "source_url": icbc_sgd_board_url}

        if maybank_sgd_board_url:
            try:
                rm = sess.get(maybank_sgd_board_url, timeout=timeout)
                rm.raise_for_status()
                sm = BeautifulSoup(rm.text, "lxml")
                mr = extract_maybank_sgd_board(sm)
                sgd_board_merged.extend(mr)
                maybank_sgd_board_meta = {"source_url": rm.url, "row_count": len(mr)}
            except requests.RequestException as e:
                maybank_sgd_board_meta = {"error": str(e), "source_url": maybank_sgd_board_url}

        if ocbc_sgd_board_url:
            try:
                ro = sess.get(ocbc_sgd_board_url, timeout=timeout)
                ro.raise_for_status()
                so = BeautifulSoup(ro.text, "lxml")
                ocr = extract_ocbc_sgd_board(so)
                sgd_board_merged.extend(ocr)
                ocbc_sgd_board_meta = {"source_url": ro.url, "row_count": len(ocr)}
            except requests.RequestException as e:
                ocbc_sgd_board_meta = {"error": str(e), "source_url": ocbc_sgd_board_url}

        if rhb_sgd_board_pdf_url:
            try:
                rr = sess.get(rhb_sgd_board_pdf_url, timeout=timeout)
                rr.raise_for_status()
                rhb_pdf_rows = extract_rhb_sgd_board_pdf(rr.content)
                sgd_board_merged.extend(rhb_pdf_rows)
                rhb_sgd_board_meta = {"source_url": rr.url, "row_count": len(rhb_pdf_rows)}
            except requests.RequestException as e:
                rhb_sgd_board_meta = {"error": str(e), "source_url": rhb_sgd_board_pdf_url}

        if sif_sgd_board_url:
            try:
                rsf = sess.get(sif_sgd_board_url, timeout=timeout)
                rsf.raise_for_status()
                ssf = BeautifulSoup(rsf.text, "lxml")
                sfr = extract_sif_sgd_board(ssf)
                sgd_board_merged.extend(sfr)
                sif_sgd_board_meta = {"source_url": rsf.url, "row_count": len(sfr)}
            except requests.RequestException as e:
                sif_sgd_board_meta = {"error": str(e), "source_url": sif_sgd_board_url}

        if scb_sgd_board_url:
            try:
                rscb = sess.get(scb_sgd_board_url, timeout=timeout)
                rscb.raise_for_status()
                sscb = BeautifulSoup(rscb.text, "lxml")
                scr = extract_scb_sgd_board(sscb)
                sgd_board_merged.extend(scr)
                scb_sgd_board_meta = {"source_url": rscb.url, "row_count": len(scr)}
            except requests.RequestException as e:
                scb_sgd_board_meta = {"error": str(e), "source_url": scb_sgd_board_url}

        if sbi_sgd_board_url:
            try:
                rsbi = sess.get(sbi_sgd_board_url, timeout=timeout)
                rsbi.raise_for_status()
                ssbi = BeautifulSoup(rsbi.text, "lxml")
                sbr = extract_sbi_sgd_board(ssbi)
                sgd_board_merged.extend(sbr)
                sbi_sgd_board_meta = {"source_url": rsbi.url, "row_count": len(sbr)}
            except requests.RequestException as e:
                sbi_sgd_board_meta = {"error": str(e), "source_url": sbi_sgd_board_url}

        if uob_sgd_board_url:
            try:
                ruob = sess.get(uob_sgd_board_url, timeout=timeout)
                ruob.raise_for_status()
                suob = BeautifulSoup(ruob.text, "lxml")
                ubr = extract_uob_sgd_board(suob)
                sgd_board_merged.extend(ubr)
                uob_sgd_board_meta = {"source_url": ruob.url, "row_count": len(ubr)}
            except requests.RequestException as e:
                uob_sgd_board_meta = {"error": str(e), "source_url": uob_sgd_board_url}

        # 15.2) FCY board（外币挂牌）
        if hl_fcy_board_url:
            try:
                r_hlfx = sess.get(hl_fcy_board_url, timeout=timeout)
                r_hlfx.raise_for_status()
                rows_hlfx = extract_hl_fcy_board(BeautifulSoup(r_hlfx.text, "lxml"))
                fx_board_merged.extend(rows_hlfx)
                hl_fcy_board_meta = {"source_url": r_hlfx.url, "row_count": len(rows_hlfx)}
            except requests.RequestException as e:
                hl_fcy_board_meta = {"error": str(e), "source_url": hl_fcy_board_url}

        if hsbc_fcy_board_url:
            try:
                r_hsfx = _get_with_hsbc_rates_fallback(sess, hsbc_fcy_board_url, timeout)
                r_hsfx.raise_for_status()
                rows_hsfx = extract_hsbc_fcy_board(BeautifulSoup(r_hsfx.text, "lxml"))
                fx_board_merged.extend(rows_hsfx)
                hsbc_fcy_board_meta = {"source_url": r_hsfx.url, "row_count": len(rows_hsfx)}
            except requests.RequestException as e:
                hsbc_fcy_board_meta = {"error": str(e), "source_url": hsbc_fcy_board_url}

        if maybank_fcy_board_url:
            try:
                r_mfx = sess.get(maybank_fcy_board_url, timeout=timeout)
                r_mfx.raise_for_status()
                rows_mfx = extract_maybank_fcy_board(BeautifulSoup(r_mfx.text, "lxml"))
                fx_board_merged.extend(rows_mfx)
                maybank_fcy_board_meta = {"source_url": r_mfx.url, "row_count": len(rows_mfx)}
            except requests.RequestException as e:
                maybank_fcy_board_meta = {"error": str(e), "source_url": maybank_fcy_board_url}

        if scb_fcy_board_url:
            try:
                r_scbfx = sess.get(scb_fcy_board_url, timeout=timeout)
                r_scbfx.raise_for_status()
                rows_scbfx = extract_scb_fcy_board(BeautifulSoup(r_scbfx.text, "lxml"))
                fx_board_merged.extend(rows_scbfx)
                scb_fcy_board_meta = {"source_url": r_scbfx.url, "row_count": len(rows_scbfx)}
            except requests.RequestException as e:
                scb_fcy_board_meta = {"error": str(e), "source_url": scb_fcy_board_url}

        if sbi_fcy_board_url:
            try:
                r_sbifx = sess.get(sbi_fcy_board_url, timeout=timeout)
                r_sbifx.raise_for_status()
                rows_sbifx = extract_sbi_fcy_board(BeautifulSoup(r_sbifx.text, "lxml"))
                fx_board_merged.extend(rows_sbifx)
                sbi_fcy_board_meta = {"source_url": r_sbifx.url, "row_count": len(rows_sbifx)}
            except requests.RequestException as e:
                sbi_fcy_board_meta = {"error": str(e), "source_url": sbi_fcy_board_url}

        if rhb_fcy_board_pdf_url:
            try:
                r_rhbfx = sess.get(rhb_fcy_board_pdf_url, timeout=timeout)
                r_rhbfx.raise_for_status()
                rows_rhbfx = extract_rhb_fcy_board_pdf(r_rhbfx.content)
                fx_board_merged.extend(rows_rhbfx)
                rhb_fcy_board_meta = {"source_url": r_rhbfx.url, "row_count": len(rows_rhbfx)}
            except requests.RequestException as e:
                rhb_fcy_board_meta = {"error": str(e), "source_url": rhb_fcy_board_pdf_url}

        # 15.3) BEA boards：JSON API
        if bea_sgd_board_api_url:
            try:
                r_bea_sgd = sess.post(bea_sgd_board_api_url, timeout=timeout)
                r_bea_sgd.raise_for_status()
                bea_sgd_json = r_bea_sgd.json()
                bea_sgd_rows = extract_bea_sgd_board_from_json(bea_sgd_json)
                sgd_board_merged.extend(bea_sgd_rows)
                bea_sgd_board_meta = {
                    "source_url": r_bea_sgd.url,
                    "row_count": len(bea_sgd_rows),
                }
            except (requests.RequestException, ValueError) as e:
                bea_sgd_board_meta = {"error": str(e), "source_url": bea_sgd_board_api_url}

        if bea_fcy_board_api_url:
            try:
                r_bea_fcy = sess.post(bea_fcy_board_api_url, timeout=timeout)
                r_bea_fcy.raise_for_status()
                bea_fcy_json = r_bea_fcy.json()
                bea_fcy_rows = extract_bea_fcy_board_from_json(bea_fcy_json)
                fx_board_merged.extend(bea_fcy_rows)
                bea_fcy_board_meta = {
                    "source_url": r_bea_fcy.url,
                    "row_count": len(bea_fcy_rows),
                }
            except (requests.RequestException, ValueError) as e:
                bea_fcy_board_meta = {"error": str(e), "source_url": bea_fcy_board_api_url}

        # 15.4) BOC board：同页同时包含 SGD/FCY
        if boc_board_url:
            try:
                rbcb = sess.get(boc_board_url, timeout=timeout)
                rbcb.raise_for_status()
                rbcb.encoding = rbcb.apparent_encoding or rbcb.encoding
                sbcb = BeautifulSoup(rbcb.text, "lxml")
                boc_rows = extract_boc_sgd_fcy_board(sbcb)
                s_rows = boc_rows.get("sgd_rows") or []
                f_rows = boc_rows.get("fx_rows") or []
                sgd_board_merged.extend(s_rows)
                fx_board_merged.extend(f_rows)
                boc_sgd_board_meta = {"source_url": rbcb.url, "row_count": len(s_rows)}
                boc_fcy_board_meta = {"source_url": rbcb.url, "row_count": len(f_rows)}
            except requests.RequestException as e:
                boc_sgd_board_meta = {"error": str(e), "source_url": boc_board_url}
                boc_fcy_board_meta = {"error": str(e), "source_url": boc_board_url}

    # 16) 收尾：把 board merge 结果写回 payload。
    payload["sgd_board_merged"] = sgd_board_merged
    payload["citi_sgd_board"] = citi_sgd_board_meta
    payload["dbs_sgd_board"] = dbs_sgd_board_meta
    payload["hl_sgd_board"] = hl_sgd_board_meta
    payload["hlf_sgd_board"] = hlf_sgd_board_meta
    payload["hsbc_sgd_board"] = hsbc_sgd_board_meta
    payload["icbc_sgd_board"] = icbc_sgd_board_meta
    payload["maybank_sgd_board"] = maybank_sgd_board_meta
    payload["ocbc_sgd_board"] = ocbc_sgd_board_meta
    payload["rhb_sgd_board_pdf"] = rhb_sgd_board_meta
    payload["sif_sgd_board"] = sif_sgd_board_meta
    payload["scb_sgd_board"] = scb_sgd_board_meta
    payload["sbi_sgd_board"] = sbi_sgd_board_meta
    payload["uob_sgd_board"] = uob_sgd_board_meta

    payload["fx_board_merged"] = fx_board_merged
    payload["hl_fcy_board"] = hl_fcy_board_meta
    payload["hsbc_fcy_board"] = hsbc_fcy_board_meta
    payload["maybank_fcy_board"] = maybank_fcy_board_meta
    payload["scb_fcy_board"] = scb_fcy_board_meta
    payload["sbi_fcy_board"] = sbi_fcy_board_meta
    payload["rhb_fcy_board_pdf"] = rhb_fcy_board_meta
    payload["bea_sgd_board"] = bea_sgd_board_meta
    payload["bea_fcy_board"] = bea_fcy_board_meta
    payload["boc_sgd_board"] = boc_sgd_board_meta
    payload["boc_fcy_board"] = boc_fcy_board_meta

    return payload


# ---------------------------------------------------------------------------
# Safety net: 自动给本模块中所有 def 加异常兜底。
# 这样即使中间 helper 出错，也不会让整体流程因未捕获异常崩溃。
# ---------------------------------------------------------------------------
from bank_safety import auto_wrap_module_functions as _auto_wrap_module_functions

_auto_wrap_module_functions(globals(), module_name=__name__)

